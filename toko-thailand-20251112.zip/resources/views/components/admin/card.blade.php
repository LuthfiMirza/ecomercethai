<div {{ $attributes->merge(['class' => 'soft-card p-6']) }}>
    {{ $slot }}
</div>
