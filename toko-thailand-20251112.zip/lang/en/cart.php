<?php

return [
    'added' => 'Product added to cart',
    'updated' => 'Cart updated',
    'removed' => 'Product removed from cart',
    'cleared' => 'Cart cleared',
    'not_found' => 'Cart item not found',
    'empty' => 'Your cart is empty',
];
