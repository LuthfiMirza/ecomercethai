<?php

return [
    'order_confirmation_subject' => 'Order Confirmation #:order_id',
    'order_status_update_subject' => 'Order Status Update #:order_id',
];
