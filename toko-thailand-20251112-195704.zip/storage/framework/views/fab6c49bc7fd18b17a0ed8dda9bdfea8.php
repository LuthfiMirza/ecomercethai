<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'categories' => [],
    'brands' => [],
    'minPrice' => null,
    'maxPrice' => null,
    'inStock' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'categories' => [],
    'brands' => [],
    'minPrice' => null,
    'maxPrice' => null,
    'inStock' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $minValue = is_numeric($minPrice) ? (float) $minPrice : null;
    $maxValue = is_numeric($maxPrice) ? (float) $maxPrice : null;
?>

<aside class="space-y-6">
  <div>
    <h3 class="text-sm font-semibold text-neutral-700 dark:text-neutral-200"><?php echo e(__('catalog.filter.categories')); ?></h3>
    <div class="mt-2 space-y-1 max-h-48 overflow-auto pr-1">
      <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <label class="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            name="category[]"
            value="<?php echo e($category['value']); ?>"
            <?php if($category['checked'] ?? false): echo 'checked'; endif; ?>
            class="rounded border-neutral-300 text-accent-500 focus:ring-accent-500 dark:border-neutral-700"
          >
          <span><?php echo e($category['label']); ?></span>
        </label>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-xs text-neutral-500"><?php echo e(__('catalog.filter.categories_empty')); ?></p>
      <?php endif; ?>
    </div>
  </div>

  <div>
    <h3 class="text-sm font-semibold text-neutral-700 dark:text-neutral-200"><?php echo e(__('catalog.filter.brands')); ?></h3>
    <div class="mt-2 space-y-1 max-h-48 overflow-auto pr-1">
      <?php $__empty_1 = true; $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <label class="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            name="brand[]"
            value="<?php echo e($brand['value']); ?>"
            <?php if($brand['checked'] ?? false): echo 'checked'; endif; ?>
            class="rounded border-neutral-300 text-accent-500 focus:ring-accent-500 dark:border-neutral-700"
          >
          <span><?php echo e($brand['label']); ?></span>
        </label>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-xs text-neutral-500"><?php echo e(__('catalog.filter.brands_empty')); ?></p>
      <?php endif; ?>
    </div>
  </div>

  <div>
    <h3 class="text-sm font-semibold text-neutral-700 dark:text-neutral-200"><?php echo e(__('catalog.filter.price')); ?></h3>
    <div class="mt-2 flex items-center gap-2">
      <input
        type="number"
        name="min_price"
        value="<?php echo e($minValue ?? ''); ?>"
        min="0"
        step="0.01"
        placeholder="<?php echo e(__('catalog.filter.price_min')); ?>"
        class="w-24 rounded-md border-neutral-300 text-sm focus:border-accent-500 focus:ring-accent-500 dark:border-neutral-700 dark:bg-neutral-800"
      >
      <span class="text-neutral-400">—</span>
      <input
        type="number"
        name="max_price"
        value="<?php echo e($maxValue ?? ''); ?>"
        min="0"
        step="0.01"
        placeholder="<?php echo e(__('catalog.filter.price_max')); ?>"
        class="w-24 rounded-md border-neutral-300 text-sm focus:border-accent-500 focus:ring-accent-500 dark:border-neutral-700 dark:bg-neutral-800"
      >
    </div>
  </div>

  <div>
    <h3 class="text-sm font-semibold text-neutral-700 dark:text-neutral-200"><?php echo e(__('catalog.filter.stock')); ?></h3>
    <label class="mt-2 flex items-center gap-2 text-sm">
      <input
        type="checkbox"
        name="in_stock"
        value="1"
        <?php if($inStock): echo 'checked'; endif; ?>
        class="rounded border-neutral-300 text-accent-500 focus:ring-accent-500 dark:border-neutral-700"
      >
      <span><?php echo e(__('catalog.filter.stock_only')); ?></span>
    </label>
  </div>

  <div class="pt-2">
    <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['type' => 'submit','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'w-full']); ?><?php echo e(__('catalog.filter.apply')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
  </div>
</aside>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/thai projek/toko-thailand/resources/views/components/filter.blade.php ENDPATH**/ ?>