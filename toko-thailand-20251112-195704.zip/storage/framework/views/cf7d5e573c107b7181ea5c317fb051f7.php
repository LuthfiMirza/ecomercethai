<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
  'title' => '',
  'breadcrumbs' => [],
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
  'title' => '',
  'breadcrumbs' => [],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="soft-card p-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
  <div>
    <?php if(!empty($breadcrumbs)): ?>
      <nav class="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
        <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $bc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($i > 0): ?>
            <span class="text-gray-400">›</span>
          <?php endif; ?>
          <?php if(!empty($bc['href'] ?? null)): ?>
            <a href="<?php echo e($bc['href']); ?>" class="inline-flex items-center rounded-xl bg-white/70 px-3 py-1.5 text-slate-500 shadow-inner hover:bg-white/90">
              <?php echo e($bc['label'] ?? ''); ?>

            </a>
          <?php else: ?>
            <span class="inline-flex items-center rounded-xl bg-white/70 px-3 py-1.5 text-slate-500 shadow-inner"><?php echo e($bc['label'] ?? ''); ?></span>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </nav>
    <?php endif; ?>
    <?php if($title): ?>
      <h1 class="text-3xl font-semibold tracking-tight text-slate-700 dark:text-white"><?php echo e($title); ?></h1>
    <?php endif; ?>
  </div>
  <div class="flex items-center gap-2">
    <?php echo e($slot); ?>

  </div>
</div>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/thai projek/toko-thailand/resources/views/components/admin/header.blade.php ENDPATH**/ ?>