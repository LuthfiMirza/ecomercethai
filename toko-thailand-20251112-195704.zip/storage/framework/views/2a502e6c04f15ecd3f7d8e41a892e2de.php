<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
  'variant' => 'primary', // primary | secondary | outline | ghost
  'size' => 'md', // sm | md | lg
  'href' => null,
  'as' => null,
  'type' => 'button',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
  'variant' => 'primary', // primary | secondary | outline | ghost
  'size' => 'md', // sm | md | lg
  'href' => null,
  'as' => null,
  'type' => 'button',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
  $base = 'inline-flex items-center justify-center font-medium rounded-2xl transition-all focus:outline-none focus-visible:ring-4 focus-visible:ring-orange-200/70 disabled:opacity-50 disabled:cursor-not-allowed';
  $sizes = [
    'sm' => 'px-3.5 py-2 text-sm',
    'md' => 'px-5 py-2.5 text-sm',
    'lg' => 'px-6 py-3 text-base',
  ][$size] ?? 'px-5 py-2.5 text-sm';
  $variants = [
    'primary' => 'bg-gradient-to-r from-orange-400 via-orange-500 to-amber-600 text-white shadow-[0_18px_40px_-25px_rgba(255,112,67,0.65)] hover:-translate-y-0.5',
    'secondary' => 'bg-neutral-900 text-white shadow-md hover:bg-neutral-800 dark:bg-neutral-700 dark:hover:bg-neutral-600',
    'outline' => 'border border-white/60 bg-white/80 text-neutral-700 shadow-inner hover:border-orange-300 backdrop-blur-xl dark:border-neutral-700 dark:bg-neutral-900/60 dark:text-neutral-100',
    'ghost' => 'bg-transparent text-neutral-700 hover:bg-white/70 dark:text-neutral-200 dark:hover:bg-neutral-800/60',
  ][$variant] ?? 'bg-gradient-to-r from-orange-400 via-orange-500 to-amber-600 text-white shadow-[0_18px_40px_-25px_rgba(255,112,67,0.65)] hover:-translate-y-0.5';
  $classes = "$base $sizes $variants ".$attributes->get('class');
  $Tag = $as ?? ($href ? 'a' : 'button');
?>
<<?php echo e($Tag); ?> <?php if($href): ?> href="<?php echo e($href); ?>" <?php endif; ?> <?php if($Tag==='button'): ?> type="<?php echo e($type); ?>" <?php endif; ?> <?php echo e($attributes->merge(['class'=>$classes])); ?>>
  <?php echo e($slot); ?>

</<?php echo e($Tag); ?>>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/thai projek/toko-thailand/resources/views/components/button.blade.php ENDPATH**/ ?>