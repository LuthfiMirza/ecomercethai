<?php
    $brandName = config('app.name', 'Lungpaeit');
    $brandLogo = asset('image/logo.jpg');
    $loginUrl = localized_route('login');
    $mobileCategories = $navMegaCategories ?? [];
?>

<header x-data="navbar()"
        x-ref="hdr"
        class="sticky top-0 z-[250] bg-white/90 dark:bg-neutral-900/80 backdrop-blur"
        role="banner">
  <!-- Topbar -->
  <div class="hidden md:block bg-[#0b0720] text-neutral-300">
    <div class="container mx-auto px-5 text-xs flex items-center justify-between h-12">
      <!-- Left items with separators, no edges -->
      <nav class="flex items-center divide-x divide-neutral-700">
        <a href="<?php echo e(route('catalog')); ?>" class="px-3 hover:text-white"><?php echo e(__('common.product')); ?></a>
        <a href="<?php echo e(route('contact')); ?>" class="px-3 hover:text-white"><?php echo e(__('common.contact_us')); ?></a>
      </nav>
      <!-- Right items: text links | language -->
      <div class="flex items-center gap-4">
        <!-- Removed Wishlist/Login from topbar per request -->
          <?php if (isset($component)) { $__componentOriginal8d3bff7d7383a45350f7495fc470d934 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d3bff7d7383a45350f7495fc470d934 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.language-switcher','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('language-switcher'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d3bff7d7383a45350f7495fc470d934)): ?>
<?php $attributes = $__attributesOriginal8d3bff7d7383a45350f7495fc470d934; ?>
<?php unset($__attributesOriginal8d3bff7d7383a45350f7495fc470d934); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d3bff7d7383a45350f7495fc470d934)): ?>
<?php $component = $__componentOriginal8d3bff7d7383a45350f7495fc470d934; ?>
<?php unset($__componentOriginal8d3bff7d7383a45350f7495fc470d934); ?>
<?php endif; ?>
      </div>
    </div>
  </div>
  <div class="container mx-auto px-4">
    <div class="flex h-16 items-center gap-3 justify-between">
      <div class="flex items-center gap-2 md:gap-3">
        <button type="button"
                class="md:hidden inline-flex h-10 w-10 items-center justify-center rounded-full border border-neutral-200 bg-white text-neutral-700 shadow-sm hover:border-accent-500 dark:bg-neutral-900 dark:text-neutral-100"
                aria-label="<?php echo e(__('common.menu')); ?>"
                x-ref="mobileTrigger"
                @click="mobileOpen = true">
          <i class="fa-solid fa-bars text-lg"></i>
        </button>
        <!-- Logo -->
        <a href="<?php echo e(route('home')); ?>" class="flex items-center gap-2" aria-label="<?php echo e(__('common.go_home')); ?>">
          <img src="<?php echo e($brandLogo); ?>" alt="<?php echo e($brandName); ?>" class="h-10 w-10 rounded-full object-cover shadow-sm" loading="lazy"/>
          <span class="font-semibold text-neutral-800 dark:text-neutral-100"><?php echo e($brandName); ?></span>
        </a>
      </div>
      

      <!-- Center Search -->
      <div class="hidden md:block w-full max-w-xl mx-2 md:mx-6 relative" x-data="{open:false}" x-on:click.outside="open=false">
        <form action="<?php echo e(route('catalog')); ?>" method="get" role="search" class="relative" x-on:submit="open=false" autocomplete="off">
          <label for="q" class="sr-only"><?php echo e(__('common.search_placeholder')); ?></label>
          <input id="q" name="q" type="search" :placeholder="t('search_placeholder')" x-on:focus="open=true" x-on:keydown.escape.window="open=false" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" class="w-full rounded-xl border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 pl-11 pr-24 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-accent-500 text-neutral-800 dark:text-neutral-100"/>
          <div class="absolute inset-y-0 left-3 flex items-center text-neutral-400">
            <i class="fa-solid fa-magnifying-glass"></i>
          </div>
          <button type="submit" class="absolute right-1 top-1 bottom-1 px-4 rounded-full bg-accent-500 hover:bg-accent-600 text-white text-sm"><?php echo e(__('common.search')); ?></button>
        </form>
        <!-- Suggestions -->
        <!-- Suggestions dropdown: right-aligned, precise under input -->
        <div x-cloak x-show="open" role="listbox" aria-label="<?php echo e(__('common.suggestions')); ?>"
             x-transition.opacity x-transition.scale.origin.top-right
             class="absolute top-full left-0 right-0 mt-2 w-full bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-2xl shadow-elevated p-2 z-[140]">
          <div class="text-xs text-neutral-500 px-2 py-1"><?php echo e(__('common.suggestions')); ?></div>
          <ul class="text-sm divide-y divide-neutral-100 dark:divide-neutral-800">
            <?php $__currentLoopData = ['RTX 4070 Ti','Gaming laptop','NVMe SSD 1TB','4K Monitor']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li>
                <a class="flex items-center justify-between px-3 py-2 hover:bg-neutral-50 dark:hover:bg-neutral-800 rounded focus:outline-none focus:ring-2 focus:ring-accent-500"
                   href="<?php echo e(route('catalog', ['q' => $s])); ?>">
                  <span><?php echo e($s); ?></span>
                  <i class="fa-solid fa-arrow-turn-down-left opacity-50"></i>
                </a>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      </div>

      <!-- Right icons (mobile only) -->
      <div class="flex items-center gap-3 md:hidden">
        <!-- Wishlist -->
        <?php if(auth()->check()): ?>
        <a href="<?php echo e(route('wishlist')); ?>" data-open-wishlist class="relative inline-flex items-center justify-center w-11 h-11 rounded-full border border-neutral-200 bg-white text-neutral-700 shadow-sm hover:border-accent-500" aria-label="<?php echo e(__('common.wishlist')); ?>">
          <i class="fa-regular fa-heart text-base"></i>
          <span data-wishlist-count data-show-zero="true" class="absolute -top-1 -right-1 inline-flex min-w-[1.15rem] h-[1.15rem] items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-semibold text-white shadow ring-1 ring-white">0</span>
        </a>
        <?php else: ?>
        <a href="<?php echo e($loginUrl); ?>" class="relative inline-flex items-center justify-center w-11 h-11 rounded-full border border-neutral-200 bg-white text-neutral-700 shadow-sm" aria-label="<?php echo e(__('common.wishlist')); ?>">
          <i class="fa-regular fa-heart text-base"></i>
        </a>
        <?php endif; ?>

        <!-- Cart -->
        <a href="<?php echo e(route('cart')); ?>" data-open-cart class="relative inline-flex items-center justify-center w-11 h-11 rounded-full border border-neutral-200 bg-white text-neutral-700 shadow-sm hover:border-accent-500" aria-label="<?php echo e(__('common.cart_title')); ?>">
          <i class="fa-solid fa-cart-shopping text-neutral-700 dark:text-neutral-200"></i>
          <span id="cart-count" class="absolute -top-1 -right-1 bg-primary-600 text-white rounded-full min-w-[1.1rem] h-[1.1rem] text-[10px] leading-[1.1rem] text-center">0</span>
        </a>

        <!-- Account -->
        <?php if(auth()->check()): ?>
        <a href="<?php echo e(route('account')); ?>" class="hidden sm:inline-flex items-center p-2 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800" aria-label="Account menu">
          <i class="fa-solid fa-user-check text-neutral-700 dark:text-neutral-200"></i>
        </a>
        <?php else: ?>
        <a href="<?php echo e(route('login')); ?>" class="hidden sm:inline-flex items-center p-2 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800" aria-label="Account menu">
          <i class="fa-regular fa-user text-neutral-700 dark:text-neutral-200"></i>
        </a>
        <?php endif; ?>

        <!-- Mobile search button -->
        <button class="md:hidden p-2 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800" x-on:click="openSearch = true" aria-label="<?php echo e(__('common.search')); ?>">
          <i class="fa-solid fa-magnifying-glass"></i>
        </button>

      </div>

      <!-- Right rail (md+): LINE ID + cart summary -->
      <?php
        $lineRaw = config('services.line.id', '@jag3901n');
        $lineNormalized = ltrim($lineRaw ?: '@jag3901n', '@');
        $lineDisplay = '@' . $lineNormalized;
      ?>
      <div class="hidden md:flex items-center gap-6">
        <!-- LINE ID -->
        <button type="button" id="nav-line" data-line-modal-open class="inline-flex items-center gap-3 text-neutral-700 dark:text-neutral-100 bg-transparent hover:text-green-600 dark:hover:text-green-400 focus:outline-none">
          <i class="fa-brands fa-line text-2xl text-green-500"></i>
          <div class="leading-tight">
            <div class="text-xs opacity-90"><?php echo e(__('common.line_id')); ?></div>
            <div class="text-sm font-medium"><?php echo e($lineDisplay); ?></div>
          </div>
        </button>
        <span class="h-8 w-px bg-neutral-200 dark:bg-neutral-700" aria-hidden="true"></span>
        <!-- Cart summary with hover preview (desktop) -->
        <div class="relative" x-data="{open:false, items:[], subtotal:0, load(){ try{ this.items=JSON.parse(localStorage.getItem('cartItems')||'[]'); this.subtotal=this.items.reduce((s,i)=>s+Number(i.price||0),0);}catch(e){ this.items=[]; this.subtotal=0; } }}"
             x-on:mouseenter="open=true; load()" x-on:mouseleave="open=false">
          <a href="<?php echo e(route('cart')); ?>" data-open-cart class="inline-flex items-center gap-3 text-neutral-700 dark:text-neutral-100">
            <i class="fa-solid fa-cart-shopping text-xl"></i>
            <div class="leading-tight">
              <div class="text-sm font-semibold text-red-500">$0.00</div>
              <div id="cart-items-count" class="text-xs opacity-90" data-template="<?php echo e(__('common.items_count', ['count' => '__COUNT__'])); ?>"><?php echo e(__('common.items_count', ['count' => 0])); ?></div>
            </div>
          </a>
          <!-- Popover -->
          <div x-cloak x-show="open" x-transition.origin.top.right
               class="absolute right-0 top-full mt-2 w-80 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl shadow-elevated overflow-hidden z-[140]"
               x-on:mouseenter="open=true" x-on:mouseleave="open=false">
            <template x-if="items.length===0">
              <div class="p-3 text-sm text-neutral-600 dark:text-neutral-300"><?php echo e(__('common.cart_empty')); ?></div>
            </template>
            <template x-if="items.length>0">
              <div>
                <ul class="max-h-60 overflow-auto divide-y divide-neutral-100 dark:divide-neutral-800 p-2">
                  <template x-for="(p,idx) in items" :key="idx">
                    <li class="flex items-center gap-3 p-3">
                      <img :src="p.image" onerror="this.style.display='none'" class="w-12 h-12 object-cover rounded" alt=""/>
                      <div class="flex-1 min-w-0">
                        <div class="text-sm font-medium text-neutral-900 dark:text-neutral-100 truncate" x-text="p.name"></div>
                        <div class="text-xs text-neutral-500" x-text="'$' + (Number(p.price)||0).toFixed(2)"></div>
                      </div>
                    </li>
                  </template>
                </ul>
                <div class="p-3 flex items-center justify-between">
                  <div class="text-sm text-neutral-600 dark:text-neutral-300"><?php echo e(__('common.subtotal')); ?></div>
                  <div class="font-semibold text-neutral-900 dark:text-neutral-100" x-text="'$' + subtotal.toFixed(2)"></div>
                </div>
                <div class="p-3 pt-0 grid grid-cols-2 gap-2">
                  <a href="<?php echo e(route('cart')); ?>" class="px-3 py-2 text-sm rounded-md border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-center hover:bg-neutral-50 dark:hover:bg-neutral-800"><?php echo e(__('common.view_cart')); ?></a>
                  <a href="<?php echo e(auth()->check() ? route('checkout') : $loginUrl); ?>" class="px-3 py-2 text-sm rounded-md <?php echo e(auth()->check() ? 'bg-accent-500 hover:bg-accent-600 text-white' : 'bg-neutral-200 text-neutral-600'); ?> text-center">
                    <?php echo e(auth()->check() ? __('common.checkout') : __('common.login')); ?>

                  </a>
                </div>
              </div>
            </template>
          </div>
        </div>
      </div>
    </div>

    <!-- Menu row -->
    <nav class="hidden md:flex items-center gap-6 h-12 text-sm" aria-label="<?php echo e(__('common.menu')); ?>">
      <!-- Left: categories + main links -->
      <div class="flex items-center gap-6">
        <?php echo $__env->make('components.mega-menu', ['categories' => $navMegaCategories ?? []], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <a href="<?php echo e(route('faqs')); ?>" class="text-neutral-700 hover:text-accent-600 dark:text-neutral-200"><?php echo e(__('common.faqs')); ?></a>
      </div>

      <!-- Right: wishlist + login/register (back to bottom row) -->
      <div class="ml-auto flex items-center gap-4">
        <div class="relative" x-data="{
              open:false,
              items:[],
              load(){
                try {
                  const raw = localStorage.getItem('wishlistItems') || '[]';
                  const parsed = JSON.parse(raw);
                  this.items = Array.isArray(parsed) ? parsed : [];
                } catch (e) {
                  this.items = [];
                }
              },
              init(){
                this.load();
                const update = (e)=>{ if(e?.detail?.items){ this.items = e.detail.items; } else { this.load(); } };
                window.addEventListener('wishlist:update', update);
                window.addEventListener('storage', ()=>this.load());
              }
            }"
             x-on:mouseenter="open=true; load()" x-on:mouseleave="open=false">
        <?php if(auth()->check()): ?>
        <a href="<?php echo e(route('wishlist')); ?>" data-open-wishlist class="inline-flex items-center gap-2 rounded-full border border-neutral-200 bg-white px-4 py-1.5 text-sm font-medium text-neutral-700 shadow-sm transition hover:border-accent-500 dark:text-neutral-200 dark:bg-neutral-900 dark:border-neutral-800">
          <i class="fa-regular fa-heart text-sm"></i>
          <span><?php echo e(__('common.wishlist')); ?></span>
          <span data-wishlist-count data-show-zero="true" class="inline-flex min-w-[1.35rem] h-[1.35rem] items-center justify-center rounded-full bg-rose-500 px-1 text-[11px] font-semibold text-white shadow ring-1 ring-white dark:ring-neutral-900">0</span>
        </a>
        <?php else: ?>
        <a href="<?php echo e($loginUrl); ?>" class="inline-flex items-center gap-2 rounded-full border border-neutral-200 bg-white px-4 py-1.5 text-sm font-medium text-neutral-700 shadow-sm transition dark:text-neutral-200 dark:bg-neutral-900 dark:border-neutral-800">
          <i class="fa-regular fa-heart text-sm"></i>
          <span><?php echo e(__('common.login')); ?></span>
        </a>
        <?php endif; ?>
          <div x-cloak x-show="open" x-transition.origin.top.right
               class="absolute right-0 top-full mt-2 w-72 soft-card p-0 overflow-hidden z-[140]"
               x-on:mouseenter="open=true" x-on:mouseleave="open=false">
            <template x-if="items.length===0">
              <div class="p-4 text-center text-sm text-neutral-500 dark:text-neutral-300"><?php echo e(__('common.wishlist_empty')); ?></div>
            </template>
            <template x-if="items.length>0">
              <div>
                <ul class="max-h-60 overflow-auto divide-y divide-neutral-100 dark:divide-neutral-800">
                  <template x-for="(p,idx) in items" :key="idx">
                    <li class="flex items-center gap-3 p-3">
                      <img :src="p.image" onerror="this.style.display='none'" class="w-12 h-12 object-cover rounded" alt=""/>
                      <div class="flex-1 min-w-0">
                        <div class="text-sm font-medium text-neutral-900 dark:text-neutral-100 truncate" x-text="p.name || 'Product'"></div>
                        <div class="text-xs text-neutral-500" x-text="p.price ? ('$' + (Number(p.price)||0).toFixed(2)) : ''"></div>
                      </div>
                    </li>
                  </template>
                </ul>
                <div class="p-3 pt-0 grid grid-cols-1 gap-2">
                  <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('wishlist')); ?>" class="btn-accent text-sm text-center">
                      <?php echo e(__('common.view_wishlist')); ?>

                    </a>
                  <?php else: ?>
                    <a href="<?php echo e($loginUrl); ?>" class="btn-accent text-sm text-center">
                      <?php echo e(__('common.login')); ?>

                    </a>
                  <?php endif; ?>
                </div>
              </div>
            </template>
          </div>
        </div>
        <?php if(auth()->check()): ?>
        <div class="relative" x-data="{open:false}" x-on:keydown.escape.window="open=false">
          <button type="button" class="inline-flex items-center gap-2 text-neutral-700 hover:text-accent-600 dark:text-neutral-200" x-on:click="open=!open">
            <i class="fa-regular fa-user"></i>
            <span><?php echo e(\Illuminate\Support\Str::limit(auth()->user()->name, 18)); ?></span>
            <i class="fa-solid fa-chevron-down text-xs opacity-80"></i>
          </button>
          <div x-cloak x-show="open" x-transition.origin.top.right
               class="absolute right-0 top-full mt-2 w-48 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl shadow-elevated overflow-hidden z-[140]"
               x-on:mouseenter="open=true" x-on:mouseleave="open=false">
            <a href="<?php echo e(route('account')); ?>" class="block px-4 py-2.5 text-sm text-neutral-700 dark:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-800"><?php echo e(__('common.dashboard')); ?></a>
            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
              <a href="<?php echo e(route('admin.dashboard')); ?>" class="block px-4 py-2.5 text-sm text-neutral-700 dark:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-800"><?php echo e(__('common.admin_panel')); ?></a>
            <?php endif; ?>
            <div class="border-t border-neutral-200 dark:border-neutral-800"></div>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
              <?php echo csrf_field(); ?>
              <button type="submit" class="w-full text-left px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-neutral-800"><?php echo e(__('common.logout')); ?></button>
            </form>
          </div>
        </div>
        <?php else: ?>
        <div class="flex items-center gap-3">
          <a href="<?php echo e(route('login')); ?>" class="text-neutral-700 hover:text-accent-600 dark:text-neutral-200"><?php echo e(__('common.login')); ?></a>
          <span class="text-neutral-300" aria-hidden="true">|</span>
          <a href="<?php echo e(route('register')); ?>" class="text-neutral-700 hover:text-accent-600 dark:text-neutral-200"><?php echo e(__('common.register')); ?></a>
        </div>
        <?php endif; ?>
      </div>
    </nav>
  </div>


  <!-- Mobile slide-over -->
  <template x-teleport="body">
    <div x-cloak
         x-show="mobileOpen"
         x-transition.opacity
         class="fixed inset-0 z-[400]"
         role="dialog"
         aria-modal="true"
         @keydown.escape.prevent.stop="closeMobile()">
      <div class="absolute inset-0 bg-black/60" @click="closeMobile()" aria-hidden="true"></div>
      <aside x-ref="mobilePanel"
             tabindex="-1"
             x-trap.noscroll="mobileOpen"
             class="absolute inset-y-0 left-0 w-full max-w-sm bg-white dark:bg-neutral-900 shadow-2xl p-6 overflow-y-auto focus:outline-none"
             x-transition:enter="transform transition ease-out duration-300"
             x-transition:enter-start="-translate-x-full"
             x-transition:enter-end="translate-x-0"
             x-transition:leave="transform transition ease-in duration-200"
             x-transition:leave-start="translate-x-0"
             x-transition:leave-end="-translate-x-full">
        <div class="flex items-center justify-between">
          <p class="text-lg font-semibold text-neutral-900 dark:text-neutral-50"><?php echo e(__('common.menu')); ?></p>
          <button type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-full bg-neutral-100 text-neutral-700 dark:bg-neutral-800 dark:text-neutral-100" @click="closeMobile()">
            <span class="sr-only"><?php echo e(__('common.close')); ?></span>
            <i class="fa-solid fa-xmark"></i>
        </button>
      </div>
      <div class="mt-6 space-y-6">
        <form action="<?php echo e(route('catalog')); ?>" method="get" role="search" class="flex items-center gap-2 rounded-2xl border border-neutral-200 bg-neutral-50 px-3 py-2 dark:border-neutral-800 dark:bg-neutral-800">
          <label for="mobile-search" class="sr-only"><?php echo e(__('common.search_placeholder')); ?></label>
          <i class="fa-solid fa-magnifying-glass text-neutral-400"></i>
          <input id="mobile-search" name="q" type="search" placeholder="<?php echo e(__('common.search_placeholder')); ?>" class="flex-1 bg-transparent text-sm text-neutral-800 outline-none dark:text-neutral-100"/>
          <button type="submit" class="text-sm font-semibold text-accent-500"><?php echo e(__('common.search')); ?></button>
        </form>
        <nav class="space-y-3 text-sm text-neutral-700 dark:text-neutral-200" aria-label="<?php echo e(__('common.menu')); ?>">
          <a href="<?php echo e(route('catalog')); ?>" class="block rounded-xl border border-neutral-200 px-4 py-2 font-semibold hover:border-accent-500 dark:border-neutral-800"><?php echo e(__('common.catalog')); ?></a>
          <a href="<?php echo e(route('faqs')); ?>" class="block rounded-xl border border-neutral-200 px-4 py-2 font-semibold hover:border-accent-500 dark:border-neutral-800"><?php echo e(__('common.faqs')); ?></a>
          <a href="<?php echo e(route('contact')); ?>" class="block rounded-xl border border-neutral-200 px-4 py-2 font-semibold hover:border-accent-500 dark:border-neutral-800"><?php echo e(__('common.contact_us')); ?></a>
        </nav>
        <div>
          <p class="text-xs font-semibold uppercase tracking-wide text-neutral-500 dark:text-neutral-400"><?php echo e(__('common.categories')); ?></p>
          <div class="mt-3 grid gap-2">
            <?php $__empty_1 = true; $__currentLoopData = $mobileCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <a href="<?php echo e($category['url'] ?? '#'); ?>" class="inline-flex items-center justify-between rounded-2xl border border-neutral-200 bg-white px-4 py-2 text-sm font-medium text-neutral-700 shadow-sm hover:border-accent-500 dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-100">
                <span><?php echo e($category['name'] ?? __('common.mega_view_category')); ?></span>
                <i class="fa-solid fa-arrow-right-long text-[10px] opacity-50"></i>
              </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <p class="text-sm text-neutral-500 dark:text-neutral-300"><?php echo e(__('common.mega_no_categories')); ?></p>
            <?php endif; ?>
          </div>
        </div>
        <div class="space-y-3">
          <p class="text-xs font-semibold uppercase tracking-wide text-neutral-500 dark:text-neutral-400"><?php echo e(__('common.account')); ?></p>
          <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('account')); ?>" class="block rounded-xl border border-neutral-200 px-4 py-2 text-sm font-semibold text-neutral-700 hover:border-accent-500 dark:border-neutral-800 dark:text-neutral-100"><?php echo e(__('common.dashboard')); ?></a>
            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
              <a href="<?php echo e(route('admin.dashboard')); ?>" class="block rounded-xl border border-neutral-200 px-4 py-2 text-sm font-semibold text-neutral-700 hover:border-accent-500 dark:border-neutral-800 dark:text-neutral-100"><?php echo e(__('common.admin_panel')); ?></a>
            <?php endif; ?>
            <a href="<?php echo e(route('wishlist')); ?>" class="block rounded-xl border border-neutral-200 px-4 py-2 text-sm font-semibold text-neutral-700 hover:border-accent-500 dark:border-neutral-800 dark:text-neutral-100"><?php echo e(__('common.wishlist')); ?></a>
            <a href="<?php echo e(route('cart')); ?>" class="block rounded-xl border border-neutral-200 px-4 py-2 text-sm font-semibold text-neutral-700 hover:border-accent-500 dark:border-neutral-800 dark:text-neutral-100"><?php echo e(__('common.view_cart')); ?></a>
          <?php else: ?>
            <a href="<?php echo e($loginUrl); ?>" class="block rounded-xl border border-neutral-200 px-4 py-2 text-sm font-semibold text-neutral-700 hover:border-accent-500 dark:border-neutral-800 dark:text-neutral-100"><?php echo e(__('common.login')); ?></a>
            <a href="<?php echo e(localized_route('register')); ?>" class="block rounded-xl border border-neutral-200 px-4 py-2 text-sm font-semibold text-neutral-700 hover:border-accent-500 dark:border-neutral-800 dark:text-neutral-100"><?php echo e(__('common.register')); ?></a>
          <?php endif; ?>
        </div>
        <div class="flex items-center justify-between rounded-2xl border border-neutral-200 px-4 py-2 text-sm font-medium text-neutral-700 dark:border-neutral-800 dark:text-neutral-100">
          <span><?php echo e(__('common.line_id')); ?></span>
          <button type="button" data-line-modal-open class="inline-flex items-center gap-1 text-accent-500">
            <i class="fa-brands fa-line"></i> LINE
          </button>
        </div>
        <div>
          <?php if (isset($component)) { $__componentOriginal8d3bff7d7383a45350f7495fc470d934 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d3bff7d7383a45350f7495fc470d934 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.language-switcher','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('language-switcher'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d3bff7d7383a45350f7495fc470d934)): ?>
<?php $attributes = $__attributesOriginal8d3bff7d7383a45350f7495fc470d934; ?>
<?php unset($__attributesOriginal8d3bff7d7383a45350f7495fc470d934); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d3bff7d7383a45350f7495fc470d934)): ?>
<?php $component = $__componentOriginal8d3bff7d7383a45350f7495fc470d934; ?>
<?php unset($__componentOriginal8d3bff7d7383a45350f7495fc470d934); ?>
<?php endif; ?>
        </div>
      </div>
    </aside>
    </div>
  </template>

  <!-- Mobile search modal -->
  <div x-cloak x-show="openSearch" x-transition.opacity class="fixed inset-0 z-[320]" aria-hidden="true">
    <div class="absolute inset-0 bg-black/40" x-on:click="openSearch=false"></div>
    <div class="absolute inset-x-4 top-16 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl shadow-elevated p-3">
      <form action="<?php echo e(route('catalog')); ?>" method="get" role="search" class="flex items-center gap-2" autocomplete="off">
        <label for="mq" class="sr-only"><?php echo e(__('common.search_placeholder')); ?></label>
        <i class="fa-solid fa-magnifying-glass text-neutral-400"></i>
        <input id="mq" name="q" type="search" placeholder="<?php echo e(__('common.search_placeholder')); ?>" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" class="flex-1 bg-transparent outline-none text-sm text-neutral-800 dark:text-neutral-100"/>
        <button type="submit" class="px-3 py-1.5 rounded-md bg-accent-500 hover:bg-accent-600 text-white text-sm"><?php echo e(__('common.search')); ?></button>
      </form>
    </div>
  </div>

  <script>
    function navbar(){
      return {
        open:false, openSearch:false, mobileOpen:false,
        lang: '<?php echo e(app()->getLocale()); ?>',
        currency: document.documentElement.dataset.currency || 'THB',
        formatter: null,
        dict: {
          en: { search_placeholder: <?php echo json_encode(__('common.search_placeholder', [], 'en')) ?> },
          th: { search_placeholder: <?php echo json_encode(__('common.search_placeholder', [], 'th')) ?> },
        },
        t(key){ return (this.dict[this.lang]||{})[key] || key; },
        closeMobile(){ this.mobileOpen = false; },
        init(){
          try {
            localStorage.setItem('lang', this.lang);
          } catch (error) {
            // ignore if storage is unavailable
          }
          document.documentElement.setAttribute('lang', this.lang);
          try {
            this.formatter = new Intl.NumberFormat(document.documentElement.getAttribute('data-locale') || document.documentElement.lang || 'en', {
              style: 'currency',
              currency: this.currency
            });
          } catch (error) {
            this.formatter = new Intl.NumberFormat('en', { style: 'currency', currency: 'USD' });
          }
          // hydrate wishlist/cart counters
          const w=document.getElementById('wishlist-count');
          let wishlistRaw = '[]';
          try {
            wishlistRaw = localStorage.getItem('wishlistItems') || '[]';
          } catch (error) {
            wishlistRaw = '[]';
          }
          let wc = 0;
          try {
            wc = (JSON.parse(wishlistRaw) || []).length;
          } catch (error) {
            wc = 0;
          }
          if(w){
            w.textContent=wc;
            if(wc===0) w.classList.add('hidden');
          }
          const cc=document.getElementById('cart-count');
          const ci=document.getElementById('cart-items-count');
          const updateCartInfo = (detail = {}) => {
            let storedCount = 0;
            let storedSubtotal = 0;
            try {
              storedCount = Number(localStorage.getItem('cartCount') || 0);
              storedSubtotal = Number(localStorage.getItem('cartSubtotal') || 0);
            } catch (error) {
              storedCount = 0;
              storedSubtotal = 0;
            }
            const count = Number(detail.count ?? storedCount);
            const subtotal = Number(detail.subtotal ?? storedSubtotal);
            if(cc){ cc.textContent=count; cc.classList.toggle('hidden', count === 0); }
            if(ci){
              const tpl = ci.dataset.template || ':count';
              const countText = String(count);
              ci.textContent = tpl.replace('__COUNT__', countText).replace(':count', countText);
              const miniSubtotal = ci.previousElementSibling;
              if (miniSubtotal && this.formatter) {
                miniSubtotal.textContent = this.formatter.format(subtotal);
              }
            }
          };
          updateCartInfo();
          window.addEventListener('cart:update', (event) => {
            updateCartInfo(event?.detail || {});
          });
          document.addEventListener('i18n:change', (e)=>{
            this.lang = e.detail.lang;
            document.documentElement.setAttribute('lang', this.lang);
          });
          this.$watch('mobileOpen', (value) => {
            try {
              document.body.classList.toggle('overflow-hidden', value);
            } catch (error) {}
            if (value) {
              this.$nextTick(() => {
                this.$refs.mobilePanel?.focus?.();
              });
            } else {
              this.$nextTick(() => {
                this.$refs.mobileTrigger?.focus?.();
              });
            }
          });
        }
      }
    }
  
</script>
</header>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/thai projek/toko-thailand/resources/views/components/navbar.blade.php ENDPATH**/ ?>