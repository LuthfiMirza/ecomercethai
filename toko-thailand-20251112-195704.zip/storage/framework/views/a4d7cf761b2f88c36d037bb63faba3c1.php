<?php $__env->startSection('content'); ?>
<?php
    $currency = config('app.currency', 'THB');
    $mainImage = $product->image_url
        ?? 'https://source.unsplash.com/900x900/?product,' . urlencode($product->slug);
    $galleryImages = collect([
        $product->image_url,
        'https://source.unsplash.com/600x600/?electronics,' . urlencode($product->slug . '1'),
        'https://source.unsplash.com/600x600/?electronics,' . urlencode($product->slug . '2'),
        'https://source.unsplash.com/600x600/?electronics,' . urlencode($product->slug . '3'),
    ])->filter()->take(4);
    $stock = max(0, (int) ($product->stock ?? 0));
    $canPurchase = $stock > 0;
    $description = $product->description ?: __('product.no_description');
?>

<main id="main" class="container py-8 md:py-10" role="main">
  <article itemscope itemtype="https://schema.org/Product">
    <meta itemprop="name" content="<?php echo e($product->name); ?>" />

    <div class="grid gap-8 lg:grid-cols-2">
      <div class="space-y-3">
        <div class="relative overflow-hidden rounded-xl border border-neutral-200 dark:border-neutral-800">
          <img loading="lazy" src="<?php echo e($mainImage); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-full object-cover"/>
        </div>
        <div class="grid grid-cols-4 gap-3">
          <?php $__currentLoopData = $galleryImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img loading="lazy" src="<?php echo e($gallery); ?>" alt="<?php echo e($product->name); ?> thumbnail" class="w-full h-24 rounded-lg border border-transparent object-cover"/>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>

      <div>
        <div class="space-y-2">
          <p class="text-sm text-neutral-500"><?php echo e($product->brand ?? $product->category->name ?? __('common.product')); ?></p>
          <h1 class="text-2xl md:text-3xl font-semibold text-neutral-900 dark:text-neutral-100"><?php echo e($product->name); ?></h1>
        </div>
        <div class="mt-4 text-3xl font-semibold text-neutral-900 dark:text-neutral-100">
          <?php echo e(format_price($product->price)); ?>

        </div>
        <div class="mt-2 text-sm text-neutral-600 dark:text-neutral-300">
          <?php echo e(__('product.stock')); ?>:
          <span class="font-medium <?php echo e($canPurchase ? 'text-emerald-600' : 'text-rose-600'); ?>">
            <?php echo e($canPurchase ? __('product.stock_available', ['qty' => $stock]) : __('product.stock_unavailable')); ?>

          </span>
        </div>

        <div class="mt-6 space-y-4">
          <form method="POST" action="<?php echo e(localized_route('cart.add')); ?>" class="space-y-4">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
            <div>
              <label for="quantity" class="text-sm font-medium text-neutral-700 dark:text-neutral-200"><?php echo e(__('product.quantity')); ?></label>
              <div class="mt-2 flex w-full max-w-xs items-center rounded-xl border border-neutral-200 dark:border-neutral-700">
                <input
                  type="number"
                  id="quantity"
                  name="quantity"
                  min="1"
                  max="<?php echo e(max(1, $stock)); ?>"
                  value="1"
                  class="w-full rounded-xl border-none bg-transparent px-4 py-2 text-base focus:outline-none"
                  <?php if(! $canPurchase): ?> disabled <?php endif; ?>
                >
              </div>
              <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-sm text-rose-600 mt-1"><?php echo e($messages[0]); ?></p>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="flex flex-wrap gap-3">
              <?php if($canPurchase): ?>
                <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['type' => 'submit','class' => 'flex-1 justify-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'flex-1 justify-center']); ?>
                  <?php echo e(__('product.add_to_cart')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
              <?php else: ?>
                <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['type' => 'button','class' => 'flex-1 justify-center','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'button','class' => 'flex-1 justify-center','disabled' => true]); ?>
                  <?php echo e(__('product.stock_unavailable')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
              <?php endif; ?>
            </div>
          </form>
          
          <div class="flex flex-wrap gap-3">
            <?php if(auth()->check()): ?>
              <button type="button"
                      data-wishlist
                      data-product-id="<?php echo e($product->id); ?>"
                      data-name="<?php echo e($product->name); ?>"
                      data-price="<?php echo e($product->price); ?>"
                      data-image="<?php echo e($product->image_url ?? $mainImage); ?>"
                      data-url="<?php echo e(localized_route('product.show', ['slug' => $product->slug])); ?>"
                      class="inline-flex items-center justify-center font-medium rounded-2xl transition-all focus:outline-none focus-visible:ring-4 focus-visible:ring-orange-200/70 disabled:opacity-50 disabled:cursor-not-allowed px-5 py-2.5 text-sm border border-white/60 bg-white/80 text-neutral-700 shadow-inner hover:border-orange-300 backdrop-blur-xl dark:border-neutral-700 dark:bg-neutral-900/60 dark:text-neutral-100"
                      aria-label="<?php echo e(__('common.wishlist')); ?>">
                <i class="fa-regular fa-heart mr-2"></i><?php echo e(__('common.wishlist')); ?>

              </button>
            <?php else: ?>
              <a href="<?php echo e(localized_route('login')); ?>" class="inline-flex items-center justify-center rounded-2xl border border-neutral-300 px-6 py-2.5 text-sm font-semibold text-neutral-700 hover:bg-neutral-50">
                <i class="fa-regular fa-heart mr-2"></i><?php echo e(__('common.wishlist_login_prompt')); ?>

              </a>
            <?php endif; ?>
          </div>
        </div>

        <div class="mt-6 border-t pt-4 text-sm text-neutral-600 dark:text-neutral-300 space-y-2">
          <div class="flex items-center gap-2"><i class="fa-solid fa-truck-fast text-accent-500"></i><span><?php echo e(__('product.fast_shipping')); ?></span></div>
          <div class="flex items-center gap-2"><i class="fa-solid fa-shield-halved text-accent-500"></i><span><?php echo e(__('product.guaranteed_warranty')); ?></span></div>
          <div class="flex items-center gap-2"><i class="fa-solid fa-rotate-left text-accent-500"></i><span><?php echo e(__('product.easy_returns')); ?></span></div>
        </div>
      </div>
    </div>

    <section class="mt-12 space-y-8">
      <div class="border-b flex gap-6 text-sm">
        <a href="#desc" class="py-2 border-b-2 border-accent-500"><?php echo e(__('product.description_tab')); ?></a>
        <a href="#spec" class="py-2"><?php echo e(__('product.details_tab')); ?></a>
      </div>
      <div id="desc" class="prose dark:prose-invert max-w-none">
        <?php echo nl2br(e($description)); ?>

      </div>
      <div id="spec" class="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
        <div class="flex justify-between border-b py-2"><span><?php echo e(__('product.brand')); ?></span><span><?php echo e($product->brand ?? __('product.not_available')); ?></span></div>
        <div class="flex justify-between border-b py-2"><span><?php echo e(__('product.category')); ?></span><span><?php echo e($product->category->name ?? __('product.general_category')); ?></span></div>
        <div class="flex justify-between border-b py-2"><span><?php echo e(__('product.stock')); ?></span><span><?php echo e($stock); ?></span></div>
        <div class="flex justify-between border-b py-2"><span><?php echo e(__('product.price')); ?></span><span><?php echo e(format_price($product->price)); ?></span></div>
      </div>
    </section>

    <?php if($relatedProducts->isNotEmpty()): ?>
    <section class="mt-12">
      <h2 class="text-xl font-semibold mb-4"><?php echo e(__('product.related_products')); ?></h2>
      <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
            $relatedImage = $related->image_url ?? 'https://source.unsplash.com/600x600/?product,' . urlencode($related->slug);
            $detailUrl = localized_route('product.show', ['slug' => $related->slug]);
          ?>
          <?php if (isset($component)) { $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-card','data' => ['href' => $detailUrl,'title' => $related->name,'price' => $related->price,'rating' => 4.8,'reviews' => $related->order_items_count ?? 0,'image' => $relatedImage,'productId' => $related->id,'currency' => '฿']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($detailUrl),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($related->name),'price' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($related->price),'rating' => 4.8,'reviews' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($related->order_items_count ?? 0),'image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($relatedImage),'product-id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($related->id),'currency' => '฿']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $attributes = $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $component = $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </section>
    <?php endif; ?>
  </article>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/thai projek/toko-thailand/resources/views/pages/product.blade.php ENDPATH**/ ?>