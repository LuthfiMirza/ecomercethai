<?php
  $shipping = collect(json_decode($order->shipping_address ?? '[]', true));
  $items = $order->orderItems ?? collect();
  $itemsTotal = $items->sum(fn($item) => $item->price * $item->quantity);
  $discountAmount = $order->discount_amount ?? 0;
  $shippingTotal = max($order->total_amount - $itemsTotal + $discountAmount, 0);
  $paymentRoutes = [
    'bank_transfer' => localized_route('payment.bank-transfer', ['order' => $order->id])
  ];
  $paymentLabels = [
    'bank_transfer' => __('Transfer Bank Manual')
  ];
  $paymentLabel = $paymentLabels[$order->payment_method] ?? ucfirst(str_replace('_', ' ', $order->payment_method));
  $paymentVerifiedAt = $order->payment_verified_at;
  $statusStages = [
    'pending' => __('Menunggu Konfirmasi'),
    'processing' => __('Sedang Diproses'),
    'shipped' => __('Dikirim'),
    'completed' => __('Selesai'),
  ];
  $stageKeys = array_keys($statusStages);
  $currentStageIndex = array_search($order->status, $stageKeys);
  $currentStageIndex = ($currentStageIndex === false) ? 0 : $currentStageIndex;
  $shippingSummary = $shipping->filter()->implode(', ');
?>

<?php $__env->startSection('content'); ?>
<main class="container max-w-5xl py-10 space-y-6" role="main">
  <div class="flex flex-wrap items-start justify-between gap-4">
    <div>
      <h1 class="text-3xl font-semibold text-neutral-900 dark:text-neutral-100"><?php echo e(__('Detail Pesanan')); ?></h1>
      <p class="text-sm text-neutral-500 dark:text-neutral-400"><?php echo e(__('Dibuat pada :date', ['date' => $order->created_at?->format('d M Y H:i')])); ?></p>
    </div>
    <div class="flex flex-col items-end gap-2">
      <div class="text-xs uppercase tracking-wide text-neutral-400"><?php echo e(__('Nomor Pesanan')); ?></div>
      <div class="text-lg font-semibold text-neutral-900 dark:text-neutral-100">#<?php echo e($order->id); ?></div>
      <div class="flex items-center gap-2 text-xs">
        <?php if (isset($component)) { $__componentOriginal2ddbc40e602c342e508ac696e52f8719 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2ddbc40e602c342e508ac696e52f8719 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge','data' => ['id' => 'order-status-badge','variant' => 'accent','dataVariant' => 'accent','dataTemplate' => ''.e(__('Status: :status', ['status' => '__STATUS__'])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'order-status-badge','variant' => 'accent','data-variant' => 'accent','data-template' => ''.e(__('Status: :status', ['status' => '__STATUS__'])).'']); ?>
          <?php echo e(__('Status: :status', ['status' => ucfirst($order->status)])); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $attributes = $__attributesOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $component = $__componentOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__componentOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
        <?php
          $paymentBadgeVariant = $order->payment_status === 'paid' ? 'success' : 'warning';
        ?>
        <?php if (isset($component)) { $__componentOriginal2ddbc40e602c342e508ac696e52f8719 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2ddbc40e602c342e508ac696e52f8719 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge','data' => ['id' => 'order-payment-badge','variant' => ''.e($paymentBadgeVariant).'','dataVariant' => ''.e($paymentBadgeVariant).'','dataTemplate' => ''.e(__('Pembayaran: :status', ['status' => '__STATUS__'])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'order-payment-badge','variant' => ''.e($paymentBadgeVariant).'','data-variant' => ''.e($paymentBadgeVariant).'','data-template' => ''.e(__('Pembayaran: :status', ['status' => '__STATUS__'])).'']); ?>
          <?php echo e(__('Pembayaran: :status', ['status' => ucfirst($order->payment_status)])); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $attributes = $__attributesOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $component = $__componentOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__componentOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
      </div>
    </div>
  </div>

  <?php if(session('success')): ?>
    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success']); ?><?php echo e(session('success')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
  <?php endif; ?>
  <?php if(session('error')): ?>
    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'error']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'error']); ?><?php echo e(session('error')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
  <?php endif; ?>

  <?php if($order->payment_status === 'pending' && isset($paymentRoutes[$order->payment_method])): ?>
    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'warning','class' => 'flex items-center justify-between']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'warning','class' => 'flex items-center justify-between']); ?>
      <div>
        <div class="font-semibold text-sm text-neutral-800 dark:text-neutral-100"><?php echo e(__('Pembayaran belum selesai')); ?></div>
        <div class="text-xs text-neutral-600 dark:text-neutral-300"><?php echo e(__('Selesaikan pembayaran menggunakan metode :method untuk mengaktifkan pemrosesan pesanan.', ['method' => $paymentLabel])); ?></div>
      </div>
      <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['href' => ''.e($paymentRoutes[$order->payment_method]).'','class' => 'justify-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e($paymentRoutes[$order->payment_method]).'','class' => 'justify-center']); ?>
        <?php echo e(__('Lanjutkan Pembayaran')); ?>

       <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
  <?php endif; ?>

  <section class="grid gap-6 lg:grid-cols-[minmax(0,1fr)_260px]">
    <div class="space-y-6">
      <div class="soft-card p-6 space-y-4">
        <h2 class="text-lg font-semibold text-neutral-900 dark:text-neutral-100"><?php echo e(__('Produk dalam Pesanan')); ?></h2>
        <div class="divide-y divide-white/60 dark:divide-neutral-800">
          <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="py-4 flex flex-wrap items-center justify-between gap-4 first:pt-0">
              <div class="flex-1 min-w-[200px]">
                <div class="text-sm font-medium text-neutral-900 dark:text-neutral-100"><?php echo e($item->product?->name ?? __('Produk')); ?></div>
                <?php if($item->product?->brand): ?>
                  <div class="text-xs text-neutral-500"><?php echo e($item->product->brand); ?></div>
                <?php endif; ?>
                <div class="text-xs text-neutral-500"><?php echo e(__('Qty: :qty', ['qty' => $item->quantity])); ?></div>
              </div>
              <div class="text-right">
                <div class="text-sm text-neutral-500"><?php echo e(format_price($item->price)); ?></div>
                <div class="font-semibold text-neutral-900 dark:text-neutral-100"><?php echo e(format_price($item->price * $item->quantity)); ?></div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>

      <div class="grid gap-6 md:grid-cols-2">
        <div class="soft-card p-6 space-y-3">
          <h2 class="text-lg font-semibold text-neutral-900 dark:text-neutral-100"><?php echo e(__('Alamat Pengiriman')); ?></h2>
          <ul class="text-sm text-neutral-600 dark:text-neutral-300 space-y-1">
            <li class="font-medium text-neutral-900 dark:text-neutral-100"><?php echo e($shipping->get('name')); ?></li>
            <li><?php echo e($shipping->get('phone')); ?></li>
            <li><?php echo e($shipping->get('address_line1')); ?></li>
            <?php if($shipping->get('address_line2')): ?>
              <li><?php echo e($shipping->get('address_line2')); ?></li>
            <?php endif; ?>
            <li><?php echo e(collect([$shipping->get('city'), $shipping->get('state'), $shipping->get('postal_code')])->filter()->implode(', ')); ?></li>
            <li><?php echo e($shipping->get('country')); ?></li>
          </ul>
        </div>
        <div class="soft-card p-6 space-y-3">
          <h2 class="text-lg font-semibold text-neutral-900 dark:text-neutral-100"><?php echo e(__('Metode Pembayaran')); ?></h2>
          <dl class="text-sm text-neutral-600 dark:text-neutral-300 space-y-2">
            <div>
              <dt class="text-xs uppercase tracking-wide text-neutral-400"><?php echo e(__('Metode')); ?></dt>
              <dd class="text-sm font-medium text-neutral-900 dark:text-neutral-100"><?php echo e($paymentLabel); ?></dd>
            </div>
            <div>
              <dt class="text-xs uppercase tracking-wide text-neutral-400"><?php echo e(__('Status Pembayaran')); ?></dt>
              <dd id="payment-status-text"><?php echo e(ucfirst($order->payment_status)); ?></dd>
            </div>
            <div id="payment-verified-wrapper" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['payment-verified-row', 'hidden' => ! $paymentVerifiedAt]); ?>">
              <dt class="text-xs uppercase tracking-wide text-neutral-400"><?php echo e(__('Diverifikasi pada')); ?></dt>
              <dd id="payment-verified-text"><?php echo e($paymentVerifiedAt?->format('d M Y H:i')); ?></dd>
            </div>
            <?php if($order->payment_proof_path): ?>
              <?php
                $proofUrl = asset('storage/' . ltrim(str_replace('\\', '/', $order->payment_proof_path), '/'));
              ?>
              <div>
                <dt class="text-xs uppercase tracking-wide text-neutral-400"><?php echo e(__('Bukti Pembayaran')); ?></dt>
                <dd>
                  <button type="button" class="text-sky-600 hover:text-sky-700" data-proof-toggle data-proof-url="<?php echo e($proofUrl); ?>">
                    <?php echo e(__('Lihat Bukti')); ?>

                  </button>
                </dd>
              </div>
            <?php endif; ?>
          </dl>
        </div>
      </div>
    </div>

    <aside class="soft-card p-6 space-y-4 h-max">
      <h2 class="text-lg font-semibold text-neutral-900 dark:text-neutral-100"><?php echo e(__('Ringkasan Pembayaran')); ?></h2>
      <dl class="text-sm text-neutral-600 dark:text-neutral-300 space-y-2">
        <div class="flex justify-between"><dt><?php echo e(__('Subtotal')); ?></dt><dd><?php echo e(format_price($itemsTotal)); ?></dd></div>
        <div class="flex justify-between"><dt><?php echo e(__('Diskon')); ?></dt><dd><?php echo e($discountAmount > 0 ? '-'.format_price($discountAmount) : format_price(0)); ?></dd></div>
        <div class="flex justify-between"><dt><?php echo e(__('Pengiriman')); ?></dt><dd><?php echo e(format_price($shippingTotal)); ?></dd></div>
        <div class="border-t border-white/60 dark:border-neutral-800 pt-3 flex justify-between text-base font-semibold text-neutral-900 dark:text-neutral-100"><dt><?php echo e(__('Total')); ?></dt><dd><?php echo e(format_price($order->total_amount)); ?></dd></div>
      </dl>
      <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'info','class' => 'text-xs']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'info','class' => 'text-xs']); ?><?php echo e(__('Status pesanan akan diperbarui secara otomatis setelah pembayaran terkonfirmasi.')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
    </aside>
  </section>
</main>

<?php if($order->payment_proof_path): ?>
  <div x-data="{ open: false }" x-cloak class="fixed inset-0 z-[120] flex items-center justify-center"
       x-show="open"
       x-on:proof-modal.window="open = true; $refs.proofImage.src = $event.detail?.url || '';"
       x-transition.opacity>
    <div class="absolute inset-0 bg-black/50" x-on:click="open = false"></div>
    <div class="relative w-[92vw] max-w-3xl rounded-3xl bg-white p-6 shadow-2xl dark:bg-neutral-900">
      <button type="button" class="absolute right-4 top-4 text-neutral-500 hover:text-neutral-700" x-on:click="open = false">
        <i class="fa-solid fa-xmark text-xl"></i>
      </button>
      <h3 class="mb-4 text-lg font-semibold text-neutral-900 dark:text-neutral-100"><?php echo e(__('Bukti Pembayaran')); ?></h3>
      <div class="max-h-[70vh] overflow-hidden rounded-2xl border border-neutral-200 dark:border-neutral-700">
        <img x-ref="proofImage" src="<?php echo e($proofUrl ?? ''); ?>" alt="Payment proof" class="w-full object-contain" loading="lazy">
      </div>
    </div>
  </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  (function () {
    const pollUrl = <?php echo json_encode(localized_route('orders.status', ['order' => $order->id]), 512) ?>;
    if (!pollUrl) {
      return;
    }

    const statusBadge = document.getElementById('order-status-badge');
    const paymentBadge = document.getElementById('order-payment-badge');
    const paymentStatusText = document.getElementById('payment-status-text');
    const paymentVerifiedWrapper = document.getElementById('payment-verified-wrapper');
    const paymentVerifiedText = document.getElementById('payment-verified-text');
    const placeholder = '__STATUS__';
    const badgeVariants = {
      accent: 'bg-accent-500/10 text-accent-600',
      neutral: 'bg-neutral-900/10 text-neutral-800 dark:bg-neutral-100/10 dark:text-neutral-200',
      success: 'bg-green-500/10 text-green-700',
      warning: 'bg-amber-500/10 text-amber-700',
      danger: 'bg-red-500/10 text-red-700',
    };

    const locale = document.documentElement?.lang || 'en';
    const dateFormatter = typeof Intl !== 'undefined'
      ? new Intl.DateTimeFormat(locale, {
          day: '2-digit',
          month: 'short',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        })
      : null;

    const formatLabel = (value) => {
      if (!value) {
        return '';
      }

      return value.toString().split('_').map((part) => {
        return part.charAt(0).toUpperCase() + part.slice(1);
      }).join(' ');
    };

    const fillTemplate = (el, label) => {
      const template = el?.dataset?.template;
      if (!template) {
        return label;
      }

      return template.replace(placeholder, label);
    };

    const applyBadgeVariant = (el, variant) => {
      if (!el) {
        return;
      }

      const target = badgeVariants[variant] ? variant : 'accent';

      Object.values(badgeVariants).forEach((classes) => {
        classes.split(' ').forEach((cls) => cls && el.classList.remove(cls));
      });

      badgeVariants[target].split(' ').forEach((cls) => cls && el.classList.add(cls));
      el.dataset.variant = target;
    };

    const updatePaymentVerified = (timestamp) => {
      if (!paymentVerifiedWrapper || !paymentVerifiedText) {
        return;
      }

      if (!timestamp) {
        paymentVerifiedWrapper.classList.add('hidden');
        paymentVerifiedText.textContent = '';
        return;
      }

      const date = new Date(timestamp);
      let formatted = timestamp;

      if (dateFormatter && !Number.isNaN(date.getTime())) {
        formatted = dateFormatter.format(date);
      }

      paymentVerifiedText.textContent = formatted;
      paymentVerifiedWrapper.classList.remove('hidden');
    };

    const updateData = (payload) => {
      if (payload.status && statusBadge) {
        const label = payload.status_label || formatLabel(payload.status);
        statusBadge.textContent = fillTemplate(statusBadge, label);
      }

      if (payload.payment_status && paymentBadge) {
        const label = payload.payment_status_label || formatLabel(payload.payment_status);
        paymentBadge.textContent = fillTemplate(paymentBadge, label);

        const variant = payload.payment_status_variant
          || (payload.payment_status === 'paid' ? 'success'
            : ['failed', 'canceled', 'cancelled', 'refunded', 'expired'].includes(payload.payment_status)
              ? 'danger'
              : 'warning');

        applyBadgeVariant(paymentBadge, variant);
      }

      if (payload.payment_status && paymentStatusText) {
        paymentStatusText.textContent = payload.payment_status_label || formatLabel(payload.payment_status);
      }

      updatePaymentVerified(payload.payment_verified_at || null);
    };

    let intervalId;

    const poll = async () => {
      try {
        const response = await fetch(pollUrl, {
          headers: {
            'Accept': 'application/json',
          },
          cache: 'no-store',
        });

        if (!response.ok) {
          throw new Error('Failed to fetch order status');
        }

        const payload = await response.json();
        updateData(payload);
      } catch (error) {
        console.warn('[order-status-poll]', error);
      }
    };

    const startPolling = () => {
      clearInterval(intervalId);
      intervalId = setInterval(poll, 10000);
    };

    poll();
    startPolling();

    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        clearInterval(intervalId);
      } else {
        poll();
        startPolling();
      }
    });

    window.addEventListener('beforeunload', () => clearInterval(intervalId));
    document.querySelectorAll('[data-proof-toggle]').forEach((button) => {
      button.addEventListener('click', () => {
        const url = button.getAttribute('data-proof-url');
        window.dispatchEvent(new CustomEvent('proof-modal', { detail: { url } }));
      });
    });
  })();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/thai projek/toko-thailand/resources/views/pages/order-detail.blade.php ENDPATH**/ ?>