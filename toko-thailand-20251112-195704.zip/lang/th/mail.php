<?php

return [
    'order_confirmation_subject' => 'ยืนยันคำสั่งซื้อ #:order_id',
    'order_status_update_subject' => 'อัปเดตสถานะคำสั่งซื้อ #:order_id',
];
