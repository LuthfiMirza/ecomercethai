<?php

return [
    'about_title' => 'เกี่ยวกับเรา',
    'about_text' => 'พันธมิตรที่คุณไว้วางใจด้านคอมพิวเตอร์และฮาร์ดแวร์ในประเทศไทย',
    'links_title' => 'ลิงก์',
    'links_deals' => 'ดีลพิเศษ',
    'links_support' => 'ฝ่ายสนับสนุน',
    'support_title' => 'การช่วยเหลือ',
    'support_shipping' => 'การจัดส่ง',
    'support_warranty' => 'การรับประกัน',
    'support_returns' => 'การคืนสินค้า',
    'newsletter_title' => 'จดหมายข่าว',
    'newsletter_label' => 'อีเมล',
    'newsletter_placeholder' => 'ที่อยู่อีเมล',
    'newsletter_button' => 'สมัครรับข่าวสาร',
    'social_facebook' => 'Facebook',
    'social_instagram' => 'Instagram',
    'social_youtube' => 'YouTube',
];
