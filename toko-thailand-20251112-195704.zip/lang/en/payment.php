<?php

return [
    'proof_uploaded' => 'Payment proof uploaded successfully',
    'already_processed' => 'Payment has already been processed',
];
