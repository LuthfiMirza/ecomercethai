<?php

return [
    'success' => 'Your message has been sent successfully',
    'error' => 'An error occurred while sending your message',
    'rate_limit' => 'Too many messages. Please try again in :minutes minutes',
];
