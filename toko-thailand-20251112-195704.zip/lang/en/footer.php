<?php

return [
    'about_title' => 'About',
    'about_text' => 'Your trusted partner for all computer and hardware needs in Thailand.',
    'links_title' => 'Links',
    'links_deals' => 'Deals',
    'links_support' => 'Support',
    'support_title' => 'Support',
    'support_shipping' => 'Shipping',
    'support_warranty' => 'Warranty',
    'support_returns' => 'Returns',
    'newsletter_title' => 'Newsletter',
    'newsletter_label' => 'Email',
    'newsletter_placeholder' => 'Email address',
    'newsletter_button' => 'Subscribe',
    'social_facebook' => 'Facebook',
    'social_instagram' => 'Instagram',
    'social_youtube' => 'YouTube',
];
